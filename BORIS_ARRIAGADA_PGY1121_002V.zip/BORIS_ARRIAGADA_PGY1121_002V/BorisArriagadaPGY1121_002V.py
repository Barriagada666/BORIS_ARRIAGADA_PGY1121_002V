def datospersona ():
  nif=input("Ingrese NIF : ")
  if nif=len(8):
    print("numero de caracteres ok!")
  nombre=input("Ingrese Nombre : ")
  edad=int(input("Ingrese Edad : "))
    if edad>=0:
      print("Edad ingresada correctamente")
     else:
       print("Edad Mal ingresada") 

def impresion():
  cert=cer.array[]
